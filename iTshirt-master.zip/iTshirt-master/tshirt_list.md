1. GitHub  티셔츠
2. 파이썬 티셔츠
3. blender 티셔츠